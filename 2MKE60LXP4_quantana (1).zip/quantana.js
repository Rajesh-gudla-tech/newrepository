let userName = document.getElementById("email");
let passWord = document.getElementById("password");
let buttenEl = document.getElementById("login")

buttenEl.onclick = function() {
    let UserEnteredName = userName.value;
    let userEnteredPass = passWord.value;
    if (userEnteredPass === "") {
        alert("Login Failed")
    } else {
        alert("Login SucessFul")
    }
}